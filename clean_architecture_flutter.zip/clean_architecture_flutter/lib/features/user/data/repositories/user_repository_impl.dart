import 'package:clean_architecture_flutter/features/user/domain/repositories/user_repository.dart';
import 'package:clean_architecture_flutter/features/user/domain/entities/user.dart';
import 'package:clean_architecture_flutter/features/user/data/services/user_api_service.dart';

class UserRepositoryImpl implements UserRepository {
  final UserApiService apiService;

  UserRepositoryImpl(this.apiService);

  @override
  Future<User> fetchUser(String userId) {
    return apiService.getUser(userId);
  }
}