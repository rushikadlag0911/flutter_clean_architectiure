// lib/features/user/data/services/user_api_service.dart
import 'package:clean_architecture_flutter/features/user/domain/entities/user.dart';

class UserApiService {
  Future<User> getUser(String userId) async {
    await Future.delayed(Duration(seconds: 2));  // Simulate network delay
    print("Fetching user data for userId: $userId");  // Debugging line

    // Simulate fetching data from an API
    return User(id: userId, name: 'John Doe', email: 'john.doe@example.com');
  }
}
