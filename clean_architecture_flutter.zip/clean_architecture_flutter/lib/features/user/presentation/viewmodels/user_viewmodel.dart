import 'package:flutter/material.dart';
import 'package:clean_architecture_flutter/features/user/domain/usecases/get_user_profile.dart';
import 'package:clean_architecture_flutter/features/user/domain/entities/user.dart';

class UserViewModel extends ChangeNotifier {
  final GetUserProfile getUserProfile;
  User? user;
  bool isLoading = false;
  String errorMessage = '';

  UserViewModel(this.getUserProfile);

  Future<void> fetchUserProfile(String userId) async {
    isLoading = true;
    notifyListeners();

    try {
      print("In try");
      user = await getUserProfile.execute(userId);
    } catch (e) {
      errorMessage = 'Failed to load user data';
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}