import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:clean_architecture_flutter/features/user/presentation/viewmodels/user_viewmodel.dart';

class UserProfilePage extends StatelessWidget {
  final String userId;

  const UserProfilePage({super.key, required this.userId});

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 1), () {
      context.read<UserViewModel>().fetchUserProfile(userId);
    });

    return Scaffold(
      appBar: AppBar(title: const Text('User Profile')),
      body: Consumer<UserViewModel>(
        builder: (context, viewModel, child) {
          if (viewModel.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          if (viewModel.errorMessage.isNotEmpty) {
            return Center(child: Text(viewModel.errorMessage));
          }
          if (viewModel.user == null) {
            return const Center(child: Text('No user found'));
          }

          final user = viewModel.user!;
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Name: ${user.name}',
                    style: const TextStyle(fontSize: 24)),
                Text('Email: ${user.email}',
                    style: const TextStyle(fontSize: 18)),
              ],
            ),
          );
        },
      ),
    );
  }
}
