import 'package:clean_architecture_flutter/features/user/domain/repositories/user_repository.dart';
import 'package:clean_architecture_flutter/features/user/domain/entities/user.dart';

class GetUserProfile {
  final UserRepository repository;

  GetUserProfile(this.repository);

  Future<User> execute(String userId) {
    return repository.fetchUser(userId);
  }
}