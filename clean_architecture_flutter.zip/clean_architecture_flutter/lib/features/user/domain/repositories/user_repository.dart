import 'package:clean_architecture_flutter/features/user/domain/entities/user.dart';

abstract class UserRepository {
  Future<User> fetchUser(String userId);
}