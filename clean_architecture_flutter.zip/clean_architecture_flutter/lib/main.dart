// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:clean_architecture_flutter/features/user/presentation/pages/user_profile_page.dart';
import 'package:clean_architecture_flutter/features/user/domain/usecases/get_user_profile.dart';
import 'package:clean_architecture_flutter/features/user/data/repositories/user_repository_impl.dart';
import 'package:clean_architecture_flutter/features/user/data/services/user_api_service.dart';
import 'package:clean_architecture_flutter/features/user/presentation/viewmodels/user_viewmodel.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider(create: (_) => UserApiService()),
        ProxyProvider<UserApiService, UserRepositoryImpl>(
          update: (context, apiService, previous) =>
              UserRepositoryImpl(apiService),
        ),
        ProxyProvider<UserRepositoryImpl, GetUserProfile>(
          update: (context, userRepositoryImpl, previous) =>
              GetUserProfile(userRepositoryImpl),
        ),
        ChangeNotifierProvider(
          create: (_) => UserViewModel(Provider.of<GetUserProfile>(context)),
        ),
      ],
      child: MaterialApp(
        title: 'Flutter Clean Architecture',
        theme: ThemeData(primarySwatch: Colors.blue),
        home: UserProfilePage(userId: '123'),
      ),
    );
  }
}
