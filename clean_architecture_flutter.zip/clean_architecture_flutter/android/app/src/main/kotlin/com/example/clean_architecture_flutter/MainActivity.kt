package com.example.clean_architecture_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
